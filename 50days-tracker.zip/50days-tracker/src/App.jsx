
import { useState } from "react";

const defaultTasks = [
  "Exercise for 1 hour (walking, weightlift)",
  "Read book for 10 pages",
  "Do Prayer 5 times",
  "Go study",
  "Journaling progress",
];

const nietzscheQuotes = [
  "He who has a why to live can bear almost any how.",
  "That which does not kill us makes us stronger.",
  "No price is too high to pay for the privilege of owning yourself.",
  "In individuals, insanity is rare; but in groups, parties, nations and epochs, it is the rule.",
  "Become who you are.",
  "He who climbs upon the highest mountains laughs at all tragedies, real or imaginary.",
  "Invisible threads are the strongest ties.",
  "One must still have chaos in oneself to be able to give birth to a dancing star."
];

function getQuoteForDay(day) {
  return nietzscheQuotes[day % nietzscheQuotes.length];
}

export default function FiftyDayTracker() {
  const [progress, setProgress] = useState(
    Array.from({ length: 50 }, () => defaultTasks.map(() => false))
  );
  const [currentDay, setCurrentDay] = useState(0);

  const toggleTask = (taskIndex) => {
    const newProgress = [...progress];
    newProgress[currentDay][taskIndex] = !newProgress[currentDay][taskIndex];
    setProgress(newProgress);
  };

  const isDayComplete = progress[currentDay].every(Boolean);
  const completedDays = progress.filter((day) => day.every(Boolean)).length;
  const todayProgress = Math.round(
    (progress[currentDay].filter(Boolean).length / defaultTasks.length) * 100
  );

  return (
    <div style={{ maxWidth: '800px', margin: 'auto', padding: '1rem' }}>
      <h1 style={{ textAlign: 'center' }}>50 Days Self-Transformation Tracker</h1>

      <div style={{ display: 'flex', justifyContent: 'space-between', margin: '1rem 0' }}>
        <button onClick={() => setCurrentDay((d) => Math.max(0, d - 1))}>
          Previous Day
        </button>
        <span><strong>Day {currentDay + 1}</strong></span>
        <button onClick={() => setCurrentDay((d) => Math.min(49, d + 1))}>
          Next Day
        </button>
      </div>

      <div style={{ padding: '1rem', border: '1px solid #ccc', borderRadius: '0.5rem', background: '#fff' }}>
        {defaultTasks.map((task, index) => (
          <div key={index} style={{ display: 'flex', alignItems: 'center', marginBottom: '0.5rem' }}>
            <input
              type="checkbox"
              checked={progress[currentDay][index]}
              onChange={() => toggleTask(index)}
            />
            <label style={{ marginLeft: '0.5rem' }}>{task}</label>
          </div>
        ))}
      </div>

      {isDayComplete && (
        <div style={{ marginTop: '1rem', padding: '1rem', background: '#d1fae5', borderRadius: '0.5rem' }}>
          <p>✅ All tasks complete for Day {currentDay + 1}! Keep going!</p>
          <p style={{ fontStyle: 'italic' }}>“{getQuoteForDay(currentDay)}” – Nietzsche</p>
        </div>
      )}

      <div style={{ marginTop: '1rem', fontSize: '0.9rem', color: '#555' }}>
        <p>✅ {completedDays} / 50 days fully completed</p>
        <p>📈 Today’s Progress: {todayProgress}%</p>
      </div>

      <div style={{ marginTop: '2rem' }}>
        <h2>📅 Overview of All 50 Days</h2>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(120px, 1fr))', gap: '0.5rem' }}>
          {progress.map((dayTasks, index) => {
            const dayDone = dayTasks.every(Boolean);
            const percent = Math.round(
              (dayTasks.filter(Boolean).length / defaultTasks.length) * 100
            );
            return (
              <div
                key={index}
                style={{
                  padding: '0.5rem',
                  border: '1px solid #ddd',
                  borderRadius: '0.5rem',
                  background: dayDone ? '#bbf7d0' : '#fff',
                  fontSize: '0.85rem',
                  textAlign: 'center'
                }}
              >
                <p><strong>Day {index + 1}</strong></p>
                <p>{percent}%</p>
                {dayDone && (
                  <p style={{ fontStyle: 'italic', fontSize: '0.75rem' }}>“{getQuoteForDay(index)}”</p>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
